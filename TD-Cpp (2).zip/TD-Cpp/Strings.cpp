#include <iostream>
#include <math.h>
#include <string>
using std::string;

//Ecrivez vos fonctions ici
class TD_Strings {
public: static int Recherche(string str) {
	throw std::exception(); // � supprimer pour faire la fonction
	//Ecrivez votre r�ponse ici ^^
}

public: static int Appartient(string str, char c) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static bool Palindrome(string str) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static bool EstPhrase(string str) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}


public: static int Sous_chaine(string str, string sub_str) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Sous_palindrome(string str) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}
};