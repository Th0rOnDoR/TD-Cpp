#include <iostream>
#include <math.h>
#include <string>
using std::string;

class TD_Imperative {

public: static bool test(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

}
public: static int sum_digits(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

}

public: static int product_digit(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

}

public: static int abs(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

}

public: static int loop(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

}

public: static int List_to_9(int x) {
	throw std::exception(); // � supprimer pour faire la fonction
	//Affichez chaque valeur et retournez la derniere si possible
}



};