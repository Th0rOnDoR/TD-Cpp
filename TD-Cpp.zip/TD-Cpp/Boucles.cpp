#include <iostream>
#include <math.h>

class TD_Boucles {

public: static int Addition(int x, int y) { //Exemple, addition de x + y en utilisant uniquement + 1
	int resultat = x;
	for (int i = 0; i < y; i++) {
		resultat = resultat + 1; //On peut aussi �crire "resultat += 1"
	}
	return resultat;
}

public: static int MultiplicationN(int x, int y) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int MultiplicationZ(int x, int y) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Puissance(int x, int n) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Fibonacci(int n) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Mirroir(int x) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Quotient(int x, int y) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}

public: static int Factorielle(int x) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
} //Pas �valu�e mais bon, elle vous sera utile

public: static int FactorielleCalculbre(int limit) {
	throw std::exception(); // � supprimer pour faire la fonction

	//Ecrivez votre r�ponse ici ^^
}


};