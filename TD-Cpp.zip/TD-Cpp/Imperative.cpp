#include <iostream>
#include <math.h>
#include <string>
using std::string;

class TD_Imperative {

public: static bool test(int n) {

}
public: static int sum_digits(int n) {

}

public: static int product_digit(int n) {

}

public: static int abs(int n) {

}

public: static int loop(int n) {

}

public: static int List_to_9(int x) {
	//Affichez chaque valeur et retournez la derniere si possible
}



};